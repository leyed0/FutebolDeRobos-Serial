#pragma once

namespace serial_app {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for commands
	/// </summary>
	public ref class commands : public System::Windows::Forms::Form
	{
	public:
		commands(System::String^ Port, System::Int32 Baud)
		{
			InitializeComponent();
			serial = gcnew System::IO::Ports::SerialPort(Port, Baud);
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~commands()
		{
			if (components)
			{
				delete components;
			}
		}
	private: bool Directionalcontroll = false;
	private: System::IO::Ports::SerialPort^  serial;
	private: System::Windows::Forms::CheckBox^  checkBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  KeyPressed;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  DataReceived;
	private: System::Windows::Forms::TextBox^  Console;

	private: System::Windows::Forms::RichTextBox^  historico;
	private: System::Windows::Forms::Timer^  timer1;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::TextBox^  CmdRIGHT;
	private: System::Windows::Forms::TextBox^  CmdDOWN;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  CmdLEFT;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  CmdUP;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label7;
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->serial = (gcnew System::IO::Ports::SerialPort(this->components));
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->KeyPressed = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->DataReceived = (gcnew System::Windows::Forms::Label());
			this->Console = (gcnew System::Windows::Forms::TextBox());
			this->historico = (gcnew System::Windows::Forms::RichTextBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->CmdRIGHT = (gcnew System::Windows::Forms::TextBox());
			this->CmdDOWN = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->CmdLEFT = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->CmdUP = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// serial
			// 
			this->serial->DataReceived += gcnew System::IO::Ports::SerialDataReceivedEventHandler(this, &commands::serial_DataReceived);
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(13, 13);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(115, 17);
			this->checkBox1->TabIndex = 0;
			this->checkBox1->Text = L"Controle Direcional";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &commands::checkBox1_CheckedChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 72);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(69, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Key Pressed:";
			// 
			// KeyPressed
			// 
			this->KeyPressed->AutoSize = true;
			this->KeyPressed->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->KeyPressed->Location = System::Drawing::Point(100, 72);
			this->KeyPressed->Name = L"KeyPressed";
			this->KeyPressed->Size = System::Drawing::Size(12, 15);
			this->KeyPressed->TabIndex = 1;
			this->KeyPressed->Text = L" ";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 101);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(82, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Data Received:";
			// 
			// DataReceived
			// 
			this->DataReceived->AutoSize = true;
			this->DataReceived->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->DataReceived->Location = System::Drawing::Point(100, 101);
			this->DataReceived->Name = L"DataReceived";
			this->DataReceived->Size = System::Drawing::Size(12, 15);
			this->DataReceived->TabIndex = 1;
			this->DataReceived->Text = L" ";
			// 
			// Console
			// 
			this->Console->Location = System::Drawing::Point(169, 45);
			this->Console->Name = L"Console";
			this->Console->Size = System::Drawing::Size(65, 20);
			this->Console->TabIndex = 1;
			this->Console->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &commands::Console_KeyDown);
			// 
			// historico
			// 
			this->historico->Location = System::Drawing::Point(240, 10);
			this->historico->Name = L"historico";
			this->historico->Size = System::Drawing::Size(276, 232);
			this->historico->TabIndex = 2;
			this->historico->Text = L"";
			// 
			// timer1
			// 
			this->timer1->Enabled = true;
			this->timer1->Tick += gcnew System::EventHandler(this, &commands::timer1_Tick);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->CmdRIGHT);
			this->groupBox1->Controls->Add(this->CmdDOWN);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->CmdLEFT);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->CmdUP);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Location = System::Drawing::Point(13, 118);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(200, 124);
			this->groupBox1->TabIndex = 3;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Comandos:";
			// 
			// CmdRIGHT
			// 
			this->CmdRIGHT->Location = System::Drawing::Point(48, 95);
			this->CmdRIGHT->Name = L"CmdRIGHT";
			this->CmdRIGHT->Size = System::Drawing::Size(100, 20);
			this->CmdRIGHT->TabIndex = 1;
			// 
			// CmdDOWN
			// 
			this->CmdDOWN->Location = System::Drawing::Point(48, 43);
			this->CmdDOWN->Name = L"CmdDOWN";
			this->CmdDOWN->Size = System::Drawing::Size(100, 20);
			this->CmdDOWN->TabIndex = 1;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(7, 98);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(41, 13);
			this->label6->TabIndex = 0;
			this->label6->Text = L"RIGHT";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(7, 46);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(42, 13);
			this->label4->TabIndex = 0;
			this->label4->Text = L"DOWN";
			// 
			// CmdLEFT
			// 
			this->CmdLEFT->Location = System::Drawing::Point(48, 69);
			this->CmdLEFT->Name = L"CmdLEFT";
			this->CmdLEFT->Size = System::Drawing::Size(100, 20);
			this->CmdLEFT->TabIndex = 1;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(7, 72);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(33, 13);
			this->label5->TabIndex = 0;
			this->label5->Text = L"LEFT";
			// 
			// CmdUP
			// 
			this->CmdUP->Location = System::Drawing::Point(48, 17);
			this->CmdUP->Name = L"CmdUP";
			this->CmdUP->Size = System::Drawing::Size(100, 20);
			this->CmdUP->TabIndex = 1;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(7, 20);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(22, 13);
			this->label3->TabIndex = 0;
			this->label3->Text = L"UP";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(10, 48);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(144, 13);
			this->label7->TabIndex = 1;
			this->label7->Text = L"Manter a caixa de texto ativa";
			// 
			// commands
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(528, 253);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->historico);
			this->Controls->Add(this->Console);
			this->Controls->Add(this->DataReceived);
			this->Controls->Add(this->KeyPressed);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->checkBox1);
			this->Name = L"commands";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"commands";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &commands::commands_FormClosing);
			this->FormClosed += gcnew System::Windows::Forms::FormClosedEventHandler(this, &commands::commands_FormClosed);
			this->Load += gcnew System::EventHandler(this, &commands::commands_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void commands_Load(System::Object^  sender, System::EventArgs^  e) {
		serial->Open();
	}
	private: System::Void commands_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
	}
	private: System::Void serial_DataReceived(System::Object^  sender, System::IO::Ports::SerialDataReceivedEventArgs^  e) {
		DataReceived->Text = serial->ReadExisting();
	}
private: System::Void Console_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
	Console->Clear();
	KeyPressed->Text = "teste";
	if (checkBox1->Checked) {
		KeyPressed->Text = Convert::ToString(e->KeyCode);
		switch (e->KeyData)
		{
		case Keys::Up:
			serial->Write(CmdUP->Text);
			break;
		case Keys::Down:
			serial->Write(CmdDOWN->Text);
			break;
		case Keys::Left:
			serial->Write(CmdLEFT->Text);
			break;
		case Keys::Right:
			serial->Write(CmdRIGHT->Text);
			break;
		default:
			break;
		}
		//DataReceived->Text = Convert::ToString(serial->ReadExisting());
	}
}
private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
	if (serial->ReadBufferSize > 0 && serial->IsOpen) {
		historico->Text += serial->ReadExisting();
	}
}
private: System::Void commands_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
	
}
private: System::Void commands_FormClosed(System::Object^  sender, System::Windows::Forms::FormClosedEventArgs^  e) {
	serial->Close();
	
}
};
}
